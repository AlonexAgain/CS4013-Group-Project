//Authors: Elliot & Saw

package team18;

import java.util.Scanner;

public class StarsStand {
	
	/*
	 * This method allows the user to selected what hotel they want
	 * After they have selected the standard branch
	 */
    public void selStar(){
        
        int starc;
        
        System.out.println("Select Star");
        System.out.println("[1] Five Star");
        System.out.println("[2] Four Star");
        System.out.println("[3] Three Star");
        
        
        Scanner scanr = new Scanner(System.in);
        
        starc = scanr.nextInt();
        
        /*
         * This if-else statement determines which hotel rooms to bring up based on the users input
         * This opens the hotels in the standard branch
         */
        if (starc == 1)
        {
            Five five5 = new Five();
            five5.standFive();
            
        }
        else if(starc == 2)
        {
            Four four4 = new Four();
            four4.standFour();
        }
        else
        {
            Three three3 = new Three();
            three3.standThree();
        }
        
        
    }
}