//Author: Saw

package team18;


import java.util.Scanner;

public class type{
	
	/*
	 * This method allows the user to decide wheteher they want to pay the standard rates or the ap rates
	 * Either the standard or ap branch is used based on the users input
	 */
    public void selType(){  

        int userIn;

        System.out.println("Please Select Options");
        System.out.println("=====================");
        
        System.out.println("[1] Standard");
        System.out.println("[2] AP");
        
        System.out.println("=====================");

        Scanner scanr = new Scanner(System.in);

        userIn = scanr.nextInt();

        /*
         *Opens the standard branch
         */
        if (userIn == 1){
            StarsStand star1 = new StarsStand();
            star1.selStar();

        }
        /*
         * Opens the ap branch
         */
        else if (userIn == 2){
            StarsAP starAP = new StarsAP();
            starAP.selStarAP();
        }
        
    }
}