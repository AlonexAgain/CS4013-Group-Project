
public class __SHELL40 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
MainMenu.main(__bluej_param0);

}}
