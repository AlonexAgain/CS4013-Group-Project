
import java.util.Scanner;

public class type{
    public void selType(){  

        int userIn;

        System.out.println("Please Select Options");
        System.out.println("=====================");
        System.out.println("[1] Standard");
        System.out.println("[2] AP");
        System.out.println("[3] Exit");
        System.out.println("=====================");

        Scanner scanr = new Scanner(System.in);

        userIn = scanr.nextInt();

        if (userIn == 1){
            Standard stan1 = new Standard();
            stan1.stand();

        }   
        else if (userIn == 2){
            AP ap1 = new AP();
            ap1.apRates();
        }
        else if (userIn == 3){
           System.out.println("Goodbye, hope to see you again");
        }
    }
}