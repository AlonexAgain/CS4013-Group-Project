//Authors: Elliot & Saw

package src.team18;

import java.util.Scanner;

public class StarsAP {
	
	/*
	 * This method allows the user to selected what hotel they want
	 * After they have selected the ap branch
	 */
    public void selStarAP(){
        
        int starc;
        
        System.out.println("Select Star");
        System.out.println("[1] Five Star");
        System.out.println("[2] Four Star");
        System.out.println("[3] Three Star");
        
        
        Scanner scanr = new Scanner(System.in);
        
        starc = scanr.nextInt();
        
        /*
         * This if-else statement determines which hotel rooms to bring up based on the users input
         * This opens the hotels in the ap branch
         */
        if (starc == 1)
        {
            FiveAP five5 = new FiveAP();
            five5.apFive();
            
        }
        else if(starc == 2)
        {
            FourAP four4 = new FourAP();
            four4.apFour();
        }
        else
        {
            ThreeAP three3 = new ThreeAP();
            three3.apThree();
        }
        
        
    }
}