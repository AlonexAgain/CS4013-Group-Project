//Authors: Darren & Darragh

package src.team18;

import java.util.Scanner;

public class ThreeAP {
	
	/*
	 * Tells the user they have selected the 3 star Hotel, from the ap branch
	 */
    public static void displayMenu2(int options[], String optionMenu[]){
        System.out.println("                   ");
        System.out.println("BestSolutions Ltd");
        System.out.println("===================");
        System.out.println("                   ");
        System.out.println("You have selected 3 star hotel");
        System.out.println("                   ");
        System.out.println("===================");

        //Loop throught the menu options from the array
        for(int i = 0; i < options.length-1; i++){

            System.out.printf("%d. %s \t \n", options[i], optionMenu[i]);
        }

        // Prints exit option, "options[options.length-1]" this will print the last option in the option array.
        // "optionMenu[optionMenu.length-1]" will print the last item in the optionMenu array.
        System.out.printf("%d. %s\n", options[options.length-1], optionMenu[optionMenu.length-1] );

        System.out.println("===================");
        System.out.print("Enter Choice: ");
        System.out.println("                   ");

    }

    /*
     * This method allows the user to select what room they want in the 3 star Hotel, coming from the ap branch
     */
    public void apThree(){

        //User input
        int userInput;

        // MainMenu Data Array
        int options[] = {1,2,3};

        //String array for choices
        String optionMenu[] = {"Classic Double", "Classic Twin", 
                "Classic Single"};

        //Exit the menu
        int Exit = options[options.length-1];

        //This will display the menu from displayMenu class
        displayMenu2(options, optionMenu);

        //Scanner setup
        Scanner scan = new Scanner(System.in);

        // Get users input
        userInput = scan.nextInt();

        //Check users value and looping main menu

        if (userInput == options[0]){
            System.out.println("Your chosen room is the: " + optionMenu[0]);
            AP CDap = new AP();
            CDap.apCD();
        }
        else if (userInput == options[1]){
            System.out.println("Your chosen room is the: " + optionMenu[1]);
            AP CTap = new AP();
            CTap.apCT();
        }
        else if (userInput == options[2]){
            System.out.println("Your chosen room is the: " + optionMenu[2]);
            AP CSap = new AP();
            CSap.apCS();
        }
        



        System.out.println("");

        System.out.println("You have now selected your room and day" );
        System.out.println("Please Enter the following details to complete your booking\n " );
    }
}