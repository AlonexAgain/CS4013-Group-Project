//Author: Darragh Walsh

package src.team18;

import java.text.SimpleDateFormat;
import java.util.Date;

	public class Date2 {
		
		/*
		 * This method records what date that the reservation was made
		 */
	    public void dateTime() {

	        System.out.println(" ");
	        Date thisDate = new Date();
	        SimpleDateFormat dateForm = new SimpleDateFormat("dd/MM/Y");
	        String myString = dateForm.format(thisDate);
	        System.out.println("You Made This Reservation On: " + myString);

	    }
	}

