//Author: Saw Pu
import java.util.Scanner;

public class type{
    public void selType(){  

        int userIn;

        System.out.println("Please Select Options");
        System.out.println("=====================");
        
        System.out.println("[1] Standard");
        System.out.println("[2] AP");
        
        System.out.println("=====================");

        Scanner scanr = new Scanner(System.in);

        userIn = scanr.nextInt();

        if (userIn == 1){
            StarsStand star1 = new StarsStand();
            star1.selStar();

        }   
        else if (userIn == 2){
            StarsAP starAP = new StarsAP();
            starAP.selStarAP();
        }
        
    }
}