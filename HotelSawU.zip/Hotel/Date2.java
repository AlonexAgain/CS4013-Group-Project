//Author: Darragh Walsh

import java.text.SimpleDateFormat;
import java.util.Date;

public class Date2 {
    public void dateTime() {

        System.out.println(" ");
        Date thisDate = new Date();
        SimpleDateFormat dateForm = new SimpleDateFormat("dd/MM/Y");
        String myString = dateForm.format(thisDate);
        System.out.println("You Made This Reservation On: " + myString);

    }
}